
const Users=
[
    {
        username: "riyuzaki",
        password: "firoz"
    },
    {
        username: "afsana",
        password: "afs"
    },
    {
        username: "shabnam",
        password: "shab"
    }
]